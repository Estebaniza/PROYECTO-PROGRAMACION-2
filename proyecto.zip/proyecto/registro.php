<?php
header('Content-Type: application/json');
require 'db.php';

$accion = $_POST['accion'] ?? '';
$placa  = strtoupper(trim($_POST['placa'] ?? ''));

if (!$placa) {
    echo json_encode(['status'=>'error','message'=>'Placa requerida']);
    exit;	
}

if ($accion === 'INGRESO') {
    // Insertar nuevo registro con hora de ingreso
    $stmt = $conn->prepare("INSERT INTO registro (placa, hora_ingreso) VALUES (?, NOW())");
    $stmt->bind_param("s", $placa);

    if ($stmt->execute()) {
        echo json_encode([
            'status'=>'ok',
            'message'=>'Ingreso registrado correctamente',
            'id'=>$stmt->insert_id
        ]);
    } else {
        echo json_encode(['status'=>'error','message'=>'Error al registrar ingreso']);
    }
    $stmt->close();
}

elseif ($accion === 'SALIDA') {
    // Actualizar el registro que no tenga hora de salida
    $stmt = $conn->prepare(
        "UPDATE registro 
         SET hora_salida = NOW()
         WHERE placa = ? AND hora_salida IS NULL
         ORDER BY hora_ingreso DESC LIMIT 1"
    );
    $stmt->bind_param("s", $placa);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo json_encode(['status'=>'ok','message'=>'Salida registrada correctamente']);
    } else {
        echo json_encode(['status'=>'error','message'=>'Valida la Placa Ingresada']);
    }
    $stmt->close();
}

else {
    echo json_encode(['status'=>'error','message'=>'Acción inválida']);
}

$conn->close();
?>
